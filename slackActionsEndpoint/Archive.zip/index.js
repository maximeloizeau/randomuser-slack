const querystring = require('querystring');
const { WebClient } = require('@slack/client');

// An access token (from your Slack app or custom integration - xoxp, xoxb, or xoxa)
const token = "xoxb-339492974626-qyi657cCA8T7ZfM4w1J1XeJV";

const web = new WebClient(token);
let juliaUser;

function pickUser(users, username) {
  const filter = username || "maximeloizeau"
  return users.find(user => 
    user.name === filter
  );
}

function sendMessage(user, messageDetails) {
  return web.im.open({
    user: user.id
  })
  .then(res => web.chat.postMessage(
    Object.assign({}, {
      channel: res.channel.id
    }, messageDetails)
  ));
}

function updateMessage(message, channel, updatedContent) {
  return web.chat.update(Object.assign({}, {
    channel: channel.id,
    text: message.text,
    ts: message.ts
  }, updatedContent));
}

function handleSelectedUserReply(payload) {
  const { actions, user } = payload;

  if(!actions.length) return Promise.reject("No actions from user");
  const action = actions[0];
  if(action.value === "yes") {
    return updateMessage(
      payload.original_message,
      payload.channel,
      { attachments: [{
        "text": `You replied "yes"`,
        "fallback": "_You replied already_",
        "color": "#3AA3E3",
        "attachment_type": "default"
      }]}
    )
    .then(() => Promise.all([
      sendMessage(user, { text: "Cool 👍" }),
      sendMessage(juliaUser, { text: `${user.real_name} accepted to review your designs 🔥` }),
    ]))
  }
  else if(action.value === "no") {
    return updateMessage(
      payload.original_message,
      payload.channel,
      { attachments: [{
        "text": `You replied "no"`,
        "fallback": "_You replied already_",
        "color": "#3AA3E3",
        "attachment_type": "default"
      }]}
    )
    .then(() => sendMessage(user, {
      text: "Oh ok then 💩"
    }))
  }
  else {

  }
}


exports.handler = (event, context, callback) => {
  const {payload} = querystring.parse(event.body);
  
  return web.users.list()
  .then(users => {
    const user = pickUser(users.members);
    juliaUser = pickUser(users.members, "julia.dirand");
  
    if (payload !== null && payload !== undefined) {
      const decodedPayload = JSON.parse(payload);
      if(decodedPayload.callback_id === "random_selected") {
        return handleSelectedUserReply(decodedPayload);
      }
    }
  })
  .then(res => callback(null, JSON.stringify(payload)));
};